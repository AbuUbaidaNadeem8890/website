// backend/src/app.ts
import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";

import authRoutes from "./routes/auth.routes";
import productRoutes from "./routes/products.routes";
import categoryRoutes from "./routes/categories.routes";
import cartRoutes from "./routes/cart.routes";
import checkoutRoutes from "./routes/checkout.routes";
import adminRoutes from "./routes/admin.routes";
import { errorHandler } from "./middleware/error.middleware";

export const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN, credentials: true }));
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // JazzCash callback posts form-encoded data

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });
app.use("/api/v1/auth", authLimiter);

const api = express.Router();
api.use(authRoutes);
api.use(productRoutes);
api.use(categoryRoutes);
api.use(cartRoutes);
api.use(checkoutRoutes);
api.use(adminRoutes);
app.use("/api/v1", api);

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use(errorHandler);
