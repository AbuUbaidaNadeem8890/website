// backend/src/routes/products.routes.ts
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../models/prisma";
import { requireAuth, requireAdmin } from "../middleware/auth.middleware";

const router = Router();

// ---- Public: list with search/filter/sort/pagination ----
router.get("/products", async (req, res, next) => {
  try {
    const {
      category,
      q,
      size,
      color,
      minPrice,
      maxPrice,
      sort = "newest",
      page = "1",
      limit = "20",
    } = req.query as Record<string, string>;

    const take = Math.min(Number(limit) || 20, 100);
    const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

    const where: any = { status: "active" };
    if (category) where.category = { slug: category };
    if (q) where.OR = [{ name: { contains: q, mode: "insensitive" } }, { description: { contains: q, mode: "insensitive" } }];
    if (size || color || minPrice || maxPrice) {
      where.variants = {
        some: {
          ...(size ? { size } : {}),
          ...(color ? { color } : {}),
          ...(minPrice ? { OR: [{ priceOverride: { gte: Number(minPrice) } }] } : {}),
          ...(maxPrice ? { OR: [{ priceOverride: { lte: Number(maxPrice) } }] } : {}),
        },
      };
    }

    const orderBy =
      sort === "price_asc" ? { basePrice: "asc" as const }
      : sort === "price_desc" ? { basePrice: "desc" as const }
      : { createdAt: "desc" as const };

    const [items, total] = await Promise.all([
      prisma.product.findMany({ where, orderBy, skip, take, include: { images: true, variants: true } }),
      prisma.product.count({ where }),
    ]);

    res.json({ items, page: Number(page), total });
  } catch (err) {
    next(err);
  }
});

router.get("/products/:slug", async (req, res, next) => {
  try {
    const product = await prisma.product.findUnique({
      where: { slug: req.params.slug },
      include: { images: true, variants: true, category: true },
    });
    if (!product || product.status !== "active") {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Product not found" } });
    }
    res.json({ product });
  } catch (err) {
    next(err);
  }
});

router.get("/products/:id/recommendations", async (req, res, next) => {
  try {
    const product = await prisma.product.findUnique({ where: { id: req.params.id } });
    if (!product) return res.status(404).json({ error: { code: "NOT_FOUND", message: "Product not found" } });

    const items = await prisma.product.findMany({
      where: {
        categoryId: product.categoryId,
        id: { not: product.id },
        status: "active",
        variants: { some: { stockStatus: { not: "out_of_stock" } } },
      },
      take: 8,
      include: { images: true },
    });
    res.json({ items });
  } catch (err) {
    next(err);
  }
});

// ---- Admin: create/update/delete ----
const variantSchema = z.object({
  sku: z.string().min(1),
  size: z.string().min(1),
  color: z.string().min(1),
  priceOverride: z.number().positive().optional(),
  stockQuantity: z.number().int().min(0),
});

const productSchema = z.object({
  name: z.string().min(1),
  slug: z.string().min(1),
  description: z.string().min(1),
  categoryId: z.string().uuid(),
  basePrice: z.number().positive(),
  status: z.enum(["draft", "active", "archived"]).default("draft"),
  variants: z.array(variantSchema).min(1, "At least one variant/SKU is required"),
});

router.post("/admin/products", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const parsed = productSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    const { variants, ...productData } = parsed.data;

    const product = await prisma.product.create({
      data: {
        ...productData,
        variants: {
          create: variants.map((v) => ({
            ...v,
            stockStatus: v.stockQuantity === 0 ? "out_of_stock" : v.stockQuantity < 5 ? "low_stock" : "in_stock",
          })),
        },
      },
      include: { variants: true },
    });
    res.status(201).json({ product });
  } catch (err) {
    next(err);
  }
});

router.put("/admin/products/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const parsed = productSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    const { variants, ...productData } = parsed.data;
    const product = await prisma.product.update({
      where: { id: req.params.id },
      data: productData,
    });
    res.json({ product });
  } catch (err) {
    next(err);
  }
});

router.delete("/admin/products/:id", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    // Soft delete preferred over hard delete so historical orders keep valid references
    await prisma.product.update({ where: { id: req.params.id }, data: { status: "archived" } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

router.patch("/admin/variants/:id/stock", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const schema = z.object({ stockQuantity: z.number().int().min(0) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    const { stockQuantity } = parsed.data;
    const stockStatus = stockQuantity === 0 ? "out_of_stock" : stockQuantity < 5 ? "low_stock" : "in_stock";

    const variant = await prisma.productVariant.update({
      where: { id: req.params.id },
      data: { stockQuantity, stockStatus },
    });
    res.json({ variant });
  } catch (err) {
    next(err);
  }
});

export default router;
