// backend/src/routes/admin.routes.ts
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../models/prisma";
import { requireAuth, requireAdmin, AuthedRequest } from "../middleware/auth.middleware";

const router = Router();
router.use(requireAuth, requireAdmin);

const orderStatusSchema = z.object({
  status: z.enum(["pending", "paid", "fulfilled", "cancelled", "refunded"]),
});

router.get("/admin/orders", async (req, res, next) => {
  try {
    const { status } = req.query as { status?: string };
    const orders = await prisma.order.findMany({
      where: status ? { status: status as any } : undefined,
      orderBy: { createdAt: "desc" },
      include: { items: true, user: { select: { fullName: true, email: true } } },
    });
    res.json({ orders });
  } catch (err) {
    next(err);
  }
});

router.patch("/admin/orders/:id/status", async (req, res, next) => {
  try {
    const parsed = orderStatusSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    const order = await prisma.order.update({
      where: { id: req.params.id },
      data: { status: parsed.data.status },
    });
    res.json({ order });
  } catch (err) {
    next(err);
  }
});

// Admin needs to fetch a product by ID (including draft/archived), unlike the public
// GET /products/:slug which only returns active products by slug.
router.get("/admin/products/:id", async (req, res, next) => {
  try {
    const product = await prisma.product.findUnique({
      where: { id: req.params.id },
      include: { variants: true, images: true, category: true },
    });
    if (!product) return res.status(404).json({ error: { code: "NOT_FOUND", message: "Product not found" } });
    res.json({ product });
  } catch (err) {
    next(err);
  }
});

// Lightweight dashboard summary: revenue, order counts, low-stock alerts.
router.get("/admin/dashboard", async (_req: AuthedRequest, res, next) => {
  try {
    const [revenueAgg, orderCounts, lowStock] = await Promise.all([
      prisma.order.aggregate({ where: { status: { in: ["paid", "fulfilled"] } }, _sum: { total: true } }),
      prisma.order.groupBy({ by: ["status"], _count: true }),
      prisma.productVariant.findMany({
        where: { stockStatus: { in: ["low_stock", "out_of_stock"] } },
        include: { product: { select: { name: true } } },
        take: 20,
      }),
    ]);

    res.json({
      totalRevenue: revenueAgg._sum.total ?? 0,
      ordersByStatus: Object.fromEntries(orderCounts.map((c) => [c.status, c._count])),
      lowStockVariants: lowStock.map((v) => ({
        sku: v.sku,
        productName: v.product.name,
        size: v.size,
        color: v.color,
        stockQuantity: v.stockQuantity,
        stockStatus: v.stockStatus,
      })),
    });
  } catch (err) {
    next(err);
  }
});

export default router;
