// backend/src/routes/cart.routes.ts
import { Router } from "express";
import { z } from "zod";
import { randomUUID } from "crypto";
import { prisma } from "../models/prisma";
import { requireAuth, AuthedRequest } from "../middleware/auth.middleware";

const router = Router();

// Resolves (or creates) a cart for either a logged-in user or a guest session cookie.
async function resolveCart(req: AuthedRequest, res: any) {
  if (req.user) {
    let cart = await prisma.cart.findUnique({ where: { userId: req.user.id }, include: { items: { include: { variant: true } } } });
    if (!cart) {
      cart = await prisma.cart.create({ data: { userId: req.user.id }, include: { items: { include: { variant: true } } } });
    }
    return cart;
  }

  let sessionToken = req.cookies?.cartSession;
  if (!sessionToken) {
    sessionToken = randomUUID();
    res.cookie("cartSession", sessionToken, { httpOnly: true, sameSite: "lax", maxAge: 90 * 24 * 60 * 60 * 1000 });
  }
  let cart = await prisma.cart.findUnique({ where: { sessionToken }, include: { items: { include: { variant: true } } } });
  if (!cart) {
    cart = await prisma.cart.create({ data: { sessionToken }, include: { items: { include: { variant: true } } } });
  }
  return cart;
}

router.get("/cart", async (req: AuthedRequest, res, next) => {
  try {
    const cart = await resolveCart(req, res);
    res.json({ cart });
  } catch (err) {
    next(err);
  }
});

const addItemSchema = z.object({
  variantId: z.string().uuid(),
  quantity: z.number().int().min(1),
});

router.post("/cart/items", async (req: AuthedRequest, res, next) => {
  try {
    const parsed = addItemSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    const { variantId, quantity } = parsed.data;

    const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
    if (!variant) return res.status(404).json({ error: { code: "NOT_FOUND", message: "Variant not found" } });
    if (variant.stockQuantity < quantity) {
      return res.status(409).json({ error: { code: "OUT_OF_STOCK", message: "Not enough stock available" } });
    }

    const cart = await resolveCart(req, res);
    await prisma.cartItem.upsert({
      where: { cartId_variantId: { cartId: cart.id, variantId } },
      update: { quantity: { increment: quantity } },
      create: { cartId: cart.id, variantId, quantity },
    });

    const updated = await prisma.cart.findUnique({ where: { id: cart.id }, include: { items: { include: { variant: true } } } });
    res.json({ cart: updated });
  } catch (err) {
    next(err);
  }
});

router.patch("/cart/items/:itemId", async (req: AuthedRequest, res, next) => {
  try {
    const schema = z.object({ quantity: z.number().int().min(1) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    await prisma.cartItem.update({ where: { id: req.params.itemId }, data: { quantity: parsed.data.quantity } });
    const cart = await resolveCart(req, res);
    res.json({ cart });
  } catch (err) {
    next(err);
  }
});

router.delete("/cart/items/:itemId", async (req: AuthedRequest, res, next) => {
  try {
    await prisma.cartItem.delete({ where: { id: req.params.itemId } });
    const cart = await resolveCart(req, res);
    res.json({ cart });
  } catch (err) {
    next(err);
  }
});

// Called immediately after login/register to fold guest cart items into the user's persistent cart.
router.post("/cart/merge", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const sessionToken = req.cookies?.cartSession;
    if (!sessionToken) return res.json({ cart: await resolveCart(req, res) });

    const guestCart = await prisma.cart.findUnique({ where: { sessionToken }, include: { items: true } });
    const userCart = await resolveCart(req, res);

    if (guestCart) {
      for (const item of guestCart.items) {
        await prisma.cartItem.upsert({
          where: { cartId_variantId: { cartId: userCart.id, variantId: item.variantId } },
          update: { quantity: { increment: item.quantity } },
          create: { cartId: userCart.id, variantId: item.variantId, quantity: item.quantity },
        });
      }
      await prisma.cart.delete({ where: { id: guestCart.id } });
      res.clearCookie("cartSession");
    }

    const merged = await prisma.cart.findUnique({ where: { id: userCart.id }, include: { items: { include: { variant: true } } } });
    res.json({ cart: merged });
  } catch (err) {
    next(err);
  }
});

export default router;
