// backend/src/routes/categories.routes.ts
import { Router } from "express";
import { prisma } from "../models/prisma";

const router = Router();

router.get("/categories", async (_req, res, next) => {
  try {
    const all = await prisma.category.findMany({ orderBy: { name: "asc" } });
    const byId = new Map(all.map((c) => [c.id, { ...c, children: [] as any[] }]));
    const roots: any[] = [];
    for (const c of byId.values()) {
      if (c.parentId && byId.has(c.parentId)) {
        byId.get(c.parentId)!.children.push(c);
      } else {
        roots.push(c);
      }
    }
    res.json({ categories: roots });
  } catch (err) {
    next(err);
  }
});

export default router;
