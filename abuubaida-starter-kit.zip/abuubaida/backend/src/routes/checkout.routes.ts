// backend/src/routes/checkout.routes.ts
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../models/prisma";
import { requireAuth, AuthedRequest } from "../middleware/auth.middleware";
import { sendOrderConfirmationEmail } from "../lib/email";
import { buildJazzCashRequest, verifyJazzCashCallback, isJazzCashSuccess } from "../lib/jazzcash";

const router = Router();

function generateOrderNumber() {
  return `AU-${Date.now().toString(36).toUpperCase()}`;
}

// Step 1: validate cart + stock, create a `pending` order snapshot, and return a
// JazzCash redirect form (actionUrl + signed fields) for the frontend to auto-submit.
router.post("/checkout/intent", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const schema = z.object({
      addressId: z.string().uuid(),
      customerMobile: z.string().regex(/^03\d{9}$/, "Enter a valid Pakistani mobile number, e.g. 03001234567"),
    });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(422).json({ error: { code: "VALIDATION_ERROR", message: parsed.error.message } });
    }
    const { addressId, customerMobile } = parsed.data;

    const cart = await prisma.cart.findUnique({
      where: { userId: req.user!.id },
      include: { items: { include: { variant: { include: { product: true } } } } },
    });
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ error: { code: "EMPTY_CART", message: "Cart is empty" } });
    }

    for (const item of cart.items) {
      if (item.variant.stockQuantity < item.quantity) {
        return res.status(409).json({
          error: { code: "OUT_OF_STOCK", message: `${item.variant.product.name} (${item.variant.sku}) is out of stock` },
        });
      }
    }

    const subtotal = cart.items.reduce((sum, item) => {
      const price = Number(item.variant.priceOverride ?? item.variant.product.basePrice);
      return sum + price * item.quantity;
    }, 0);
    const tax = 0; // plug in FBR/provincial tax logic per region if required
    const shippingFee = subtotal > 5000 ? 0 : 250; // flat-rate example, PKR
    const total = Number((subtotal + tax + shippingFee).toFixed(2));

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });

    const order = await prisma.order.create({
      data: {
        userId: req.user!.id,
        orderNumber: generateOrderNumber(),
        status: "pending",
        subtotal,
        tax,
        shippingFee,
        total,
        shippingAddressId: addressId,
        items: {
          create: cart.items.map((item) => ({
            variantId: item.variantId,
            productNameSnapshot: item.variant.product.name,
            skuSnapshot: item.variant.sku,
            unitPriceSnapshot: Number(item.variant.priceOverride ?? item.variant.product.basePrice),
            quantity: item.quantity,
          })),
        },
      },
    });

    const jazzCashRequest = buildJazzCashRequest({
      orderId: order.id,
      orderNumber: order.orderNumber,
      amountPkr: total,
      customerMobile,
      customerEmail: user!.email,
    });

    await prisma.payment.create({
      data: {
        orderId: order.id,
        provider: "jazzcash",
        providerRef: jazzCashRequest.txnRefNo,
        status: "requires_payment",
        amount: total,
      },
    });

    // Frontend renders a hidden auto-submitting form to actionUrl with these fields.
    res.json({ orderId: order.id, actionUrl: jazzCashRequest.actionUrl, fields: jazzCashRequest.fields });
  } catch (err) {
    next(err);
  }
});

// Step 2: JazzCash redirects/POSTs the customer back here after payment.
// No auth middleware — this is called by JazzCash's servers/browser redirect, not our SPA.
router.post("/checkout/callback/jazzcash", async (req, res, next) => {
  try {
    const body = req.body as Record<string, string>;

    if (!verifyJazzCashCallback(body)) {
      return res.status(400).json({ error: { code: "INVALID_SIGNATURE", message: "Callback hash verification failed" } });
    }

    const orderId = body.ppmpf_1;
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true, payment: true, user: true },
    });
    if (!order) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Order not found" } });
    }
    if (order.status === "paid") {
      return res.redirect(`${process.env.FRONTEND_URL}/order-confirmation/${order.id}`); // idempotent
    }

    if (!isJazzCashSuccess(body)) {
      await prisma.payment.update({ where: { orderId: order.id }, data: { status: "failed" } });
      await prisma.order.update({ where: { id: order.id }, data: { status: "cancelled" } });
      return res.redirect(`${process.env.FRONTEND_URL}/checkout/failed?order=${order.orderNumber}`);
    }

    // Decrement stock + mark paid transactionally to avoid overselling.
    const updatedOrder = await prisma.$transaction(async (tx) => {
      for (const item of order.items) {
        const variant = await tx.productVariant.findUnique({ where: { id: item.variantId } });
        if (!variant || variant.stockQuantity < item.quantity) {
          throw new Error("STOCK_CONFLICT");
        }
        const newQty = variant.stockQuantity - item.quantity;
        await tx.productVariant.update({
          where: { id: item.variantId },
          data: {
            stockQuantity: newQty,
            stockStatus: newQty === 0 ? "out_of_stock" : newQty < 5 ? "low_stock" : "in_stock",
          },
        });
      }
      await tx.payment.update({
        where: { orderId: order.id },
        data: { status: "succeeded", providerRef: body.pp_RetreivalReferenceNo ?? order.payment!.providerRef },
      });
      return tx.order.update({ where: { id: order.id }, data: { status: "paid" } });
    });

    const cart = await prisma.cart.findUnique({ where: { userId: order.userId } });
    if (cart) await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });

    await sendOrderConfirmationEmail(order.user.email, updatedOrder);

    return res.redirect(`${process.env.FRONTEND_URL}/order-confirmation/${order.id}`);
  } catch (err: any) {
    if (err.message === "STOCK_CONFLICT") {
      return res.redirect(`${process.env.FRONTEND_URL}/checkout/failed?reason=out_of_stock`);
    }
    next(err);
  }
});

// Polled by the frontend's "waiting for payment" screen since JazzCash owns the redirect.
router.get("/checkout/status/:orderId", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const order = await prisma.order.findUnique({ where: { id: req.params.orderId } });
    if (!order || order.userId !== req.user!.id) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Order not found" } });
    }
    res.json({ status: order.status });
  } catch (err) {
    next(err);
  }
});

router.get("/orders", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const orders = await prisma.order.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: "desc" },
      include: { items: true },
    });
    res.json({ orders });
  } catch (err) {
    next(err);
  }
});

router.get("/orders/:id", requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const order = await prisma.order.findUnique({ where: { id: req.params.id }, include: { items: true } });
    if (!order || order.userId !== req.user!.id) {
      return res.status(404).json({ error: { code: "NOT_FOUND", message: "Order not found" } });
    }
    res.json({ order });
  } catch (err) {
    next(err);
  }
});

export default router;
