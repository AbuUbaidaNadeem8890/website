// backend/src/lib/jazzcash.ts
//
// JazzCash Mobile Wallet API (sandbox/test mode) — hosted-checkout style flow:
//   1. Server builds a signed request payload and hands the frontend a redirect form/URL.
//   2. Customer completes payment on JazzCash's page (enters wallet PIN / card there —
//      card & wallet credentials never touch our server, same PCI-minimal posture as Stripe).
//   3. JazzCash POSTs a signed callback to our /checkout/callback/jazzcash endpoint.
//   4. We verify the secure hash, then confirm/fulfil the order server-side.
//
// Swap JAZZCASH_* env vars for Easypaisa's equivalents to add it as a second option in Phase 2 —
// the surrounding order/stock logic in checkout.routes.ts stays provider-agnostic.

import crypto from "crypto";

const {
  JAZZCASH_MERCHANT_ID,
  JAZZCASH_PASSWORD,
  JAZZCASH_INTEGRITY_SALT,
  JAZZCASH_SANDBOX_URL = "https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform/",
  JAZZCASH_RETURN_URL,
} = process.env;

export interface JazzCashRequestParams {
  orderId: string;
  orderNumber: string;
  amountPkr: number; // e.g. 1500.00
  customerMobile: string; // 03XXXXXXXXX
  customerEmail: string;
}

// JazzCash requires amount in paisa as an integer string, and a specific date format.
function toPaisa(amount: number) {
  return Math.round(amount * 100).toString();
}

function timestamp() {
  const d = new Date();
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

// JazzCash's HMAC-SHA256 "Secure Hash" is computed over all pp_* fields, alphabetically
// sorted by key, concatenated with '&', prefixed with the integrity salt.
function buildSecureHash(fields: Record<string, string>) {
  const sortedKeys = Object.keys(fields).filter((k) => fields[k] !== "").sort();
  const joined = sortedKeys.map((k) => fields[k]).join("&");
  const hashInput = `${JAZZCASH_INTEGRITY_SALT}&${joined}`;
  return crypto.createHmac("sha256", JAZZCASH_INTEGRITY_SALT!).update(hashInput).digest("hex").toUpperCase();
}

export function buildJazzCashRequest(params: JazzCashRequestParams) {
  const txnRefNo = `T${params.orderNumber.replace(/[^A-Z0-9]/g, "")}`;
  const txnDateTime = timestamp();
  const expiry = new Date(Date.now() + 60 * 60 * 1000); // 1 hour expiry window
  const pad = (n: number) => n.toString().padStart(2, "0");
  const expiryDateTime = `${expiry.getFullYear()}${pad(expiry.getMonth() + 1)}${pad(expiry.getDate())}${pad(expiry.getHours())}${pad(expiry.getMinutes())}${pad(expiry.getSeconds())}`;

  const fields: Record<string, string> = {
    pp_Version: "1.1",
    pp_TxnType: "MWALLET",
    pp_Language: "EN",
    pp_MerchantID: JAZZCASH_MERCHANT_ID!,
    pp_Password: JAZZCASH_PASSWORD!,
    pp_TxnRefNo: txnRefNo,
    pp_Amount: toPaisa(params.amountPkr),
    pp_TxnCurrency: "PKR",
    pp_TxnDateTime: txnDateTime,
    pp_BillReference: params.orderNumber,
    pp_Description: `AbuUbaida order ${params.orderNumber}`,
    pp_TxnExpiryDateTime: expiryDateTime,
    pp_ReturnURL: JAZZCASH_RETURN_URL!,
    pp_MobileNumber: params.customerMobile,
    ppmpf_1: params.orderId, // pass-through field so the callback can look up the order
  };

  const secureHash = buildSecureHash(fields);

  return {
    actionUrl: JAZZCASH_SANDBOX_URL,
    txnRefNo,
    fields: { ...fields, pp_SecureHash: secureHash },
  };
}

// Verifies an inbound callback's secure hash before trusting its contents.
export function verifyJazzCashCallback(body: Record<string, string>): boolean {
  const { pp_SecureHash, ...rest } = body;
  const expected = buildSecureHash(rest);
  return expected === pp_SecureHash;
}

export function isJazzCashSuccess(body: Record<string, string>) {
  // "000" is JazzCash's success response code
  return body.pp_ResponseCode === "000";
}
