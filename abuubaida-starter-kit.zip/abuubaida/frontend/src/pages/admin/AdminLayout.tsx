// frontend/src/pages/admin/AdminLayout.tsx
import { NavLink, Outlet } from "react-router-dom";
import { LayoutGrid, Shirt, Receipt, ArrowLeft } from "lucide-react";

const navItems = [
  { to: "/admin", label: "Dashboard", icon: LayoutGrid, end: true },
  { to: "/admin/products", label: "Products", icon: Shirt },
  { to: "/admin/orders", label: "Orders", icon: Receipt },
];

export function AdminLayout() {
  return (
    <div className="min-h-screen bg-[#F7F4EF] text-[#1C1C1E]">
      <div className="flex">
        <aside className="sticky top-0 h-screen w-60 shrink-0 border-r border-[#E4E0D8] bg-white px-4 py-6">
          <div className="mb-8 px-2">
            <p className="font-serif text-lg tracking-tight">AbuUbaida</p>
            <p className="text-xs uppercase tracking-wide text-[#8C8A85]">Admin</p>
          </div>
          <nav className="space-y-1">
            {navItems.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                    isActive ? "bg-[#1C1C1E] text-[#F7F4EF]" : "text-[#1C1C1E] hover:bg-[#F0ECE3]"
                  }`
                }
              >
                <Icon size={16} />
                {label}
              </NavLink>
            ))}
          </nav>
          <a
            href="/"
            className="mt-8 flex items-center gap-2 px-3 text-xs text-[#8C8A85] hover:text-[#1C1C1E]"
          >
            <ArrowLeft size={14} /> Back to store
          </a>
        </aside>

        <main className="flex-1 px-8 py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
