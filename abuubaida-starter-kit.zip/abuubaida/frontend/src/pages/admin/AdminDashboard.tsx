// frontend/src/pages/admin/AdminDashboard.tsx
import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import { api } from "../../api/client";

interface DashboardData {
  totalRevenue: number;
  ordersByStatus: Record<string, number>;
  lowStockVariants: { sku: string; productName: string; size: string; color: string; stockQuantity: number; stockStatus: string }[];
}

export function AdminDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);

  useEffect(() => {
    api.get<DashboardData>("/admin/dashboard").then(setData);
  }, []);

  if (!data) return <p className="text-[#8C8A85]">Loading dashboard…</p>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-serif text-2xl">Dashboard</h1>
        <p className="text-sm text-[#8C8A85]">Snapshot of store performance.</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Total revenue" value={`Rs. ${Number(data.totalRevenue).toFixed(0)}`} />
        <StatCard label="Pending" value={String(data.ordersByStatus.pending ?? 0)} />
        <StatCard label="Paid" value={String(data.ordersByStatus.paid ?? 0)} />
        <StatCard label="Fulfilled" value={String(data.ordersByStatus.fulfilled ?? 0)} />
      </div>

      <div>
        <h2 className="mb-3 flex items-center gap-2 font-serif text-lg">
          <AlertTriangle size={18} className="text-[#A98F63]" /> Low stock / out of stock
        </h2>
        {data.lowStockVariants.length === 0 ? (
          <p className="text-sm text-[#8C8A85]">Everything is well stocked.</p>
        ) : (
          <div className="overflow-hidden rounded-lg border border-[#E4E0D8] bg-white">
            <table className="w-full text-sm">
              <thead className="border-b border-[#E4E0D8] bg-[#F7F4EF] text-left text-xs uppercase tracking-wide text-[#8C8A85]">
                <tr>
                  <th className="px-4 py-2">Product</th>
                  <th className="px-4 py-2">SKU</th>
                  <th className="px-4 py-2">Variant</th>
                  <th className="px-4 py-2">Stock</th>
                </tr>
              </thead>
              <tbody>
                {data.lowStockVariants.map((v) => (
                  <tr key={v.sku} className="border-b border-[#F0ECE3] last:border-0">
                    <td className="px-4 py-2">{v.productName}</td>
                    <td className="px-4 py-2">{v.sku}</td>
                    <td className="px-4 py-2">
                      {v.size} / {v.color}
                    </td>
                    <td className="px-4 py-2">
                      <span
                        className={`rounded px-2 py-0.5 text-xs ${
                          v.stockStatus === "out_of_stock" ? "bg-[#A5433A]/10 text-[#A5433A]" : "bg-[#A98F63]/15 text-[#A98F63]"
                        }`}
                      >
                        {v.stockQuantity}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-[#E4E0D8] bg-white p-4">
      <p className="text-xs uppercase tracking-wide text-[#8C8A85]">{label}</p>
      <p className="mt-1 font-serif text-2xl">{value}</p>
    </div>
  );
}
