// frontend/src/pages/admin/AdminOrders.tsx
import { useEffect, useState } from "react";
import { api } from "../../api/client";

interface OrderRow {
  id: string;
  orderNumber: string;
  status: "pending" | "paid" | "fulfilled" | "cancelled" | "refunded";
  total: number;
  createdAt: string;
  user: { fullName: string; email: string };
  items: { productNameSnapshot: string; quantity: number }[];
}

const statusOptions: OrderRow["status"][] = ["pending", "paid", "fulfilled", "cancelled", "refunded"];

const statusStyles: Record<OrderRow["status"], string> = {
  pending: "bg-[#A98F63]/15 text-[#A98F63]",
  paid: "bg-[#4B7355]/10 text-[#4B7355]",
  fulfilled: "bg-[#1C1C1E]/10 text-[#1C1C1E]",
  cancelled: "bg-[#A5433A]/10 text-[#A5433A]",
  refunded: "bg-[#8C8A85]/15 text-[#8C8A85]",
};

export function AdminOrders() {
  const [orders, setOrders] = useState<OrderRow[] | null>(null);
  const [filter, setFilter] = useState<string>("");

  async function load() {
    const { orders } = await api.get<{ orders: OrderRow[] }>(`/admin/orders${filter ? `?status=${filter}` : ""}`);
    setOrders(orders);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  async function handleStatusChange(orderId: string, status: OrderRow["status"]) {
    await api.patch(`/admin/orders/${orderId}/status`, { status });
    load();
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl">Orders</h1>
        <p className="text-sm text-[#8C8A85]">View and fulfil customer orders.</p>
      </div>

      <div className="mb-4 flex gap-2">
        <FilterChip label="All" active={filter === ""} onClick={() => setFilter("")} />
        {statusOptions.map((s) => (
          <FilterChip key={s} label={s} active={filter === s} onClick={() => setFilter(s)} />
        ))}
      </div>

      <div className="overflow-hidden rounded-lg border border-[#E4E0D8] bg-white">
        <table className="w-full text-sm">
          <thead className="border-b border-[#E4E0D8] bg-[#F7F4EF] text-left text-xs uppercase tracking-wide text-[#8C8A85]">
            <tr>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Items</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Placed</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {orders === null && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-[#8C8A85]">
                  Loading…
                </td>
              </tr>
            )}
            {orders?.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-[#8C8A85]">
                  No orders match this filter.
                </td>
              </tr>
            )}
            {orders?.map((o) => (
              <tr key={o.id} className="border-b border-[#F0ECE3] last:border-0 align-top">
                <td className="px-4 py-3 font-medium">{o.orderNumber}</td>
                <td className="px-4 py-3">
                  <div>{o.user.fullName}</div>
                  <div className="text-xs text-[#8C8A85]">{o.user.email}</div>
                </td>
                <td className="px-4 py-3 text-xs text-[#8C8A85]">
                  {o.items.map((i) => `${i.quantity}× ${i.productNameSnapshot}`).join(", ")}
                </td>
                <td className="px-4 py-3">Rs. {Number(o.total).toFixed(2)}</td>
                <td className="px-4 py-3 text-xs">{new Date(o.createdAt).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <select
                    value={o.status}
                    onChange={(e) => handleStatusChange(o.id, e.target.value as OrderRow["status"])}
                    className={`rounded px-2 py-1 text-xs capitalize ${statusStyles[o.status]}`}
                  >
                    {statusOptions.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function FilterChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1 text-xs capitalize ${
        active ? "bg-[#1C1C1E] text-[#F7F4EF]" : "bg-white text-[#8C8A85] border border-[#E4E0D8]"
      }`}
    >
      {label}
    </button>
  );
}
