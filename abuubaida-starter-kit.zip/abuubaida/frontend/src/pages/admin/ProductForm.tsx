// frontend/src/pages/admin/ProductForm.tsx
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Trash2, Plus } from "lucide-react";
import { api } from "../../api/client";

interface VariantDraft {
  sku: string;
  size: string;
  color: string;
  stockQuantity: number;
  priceOverride?: number;
}

interface Category {
  id: string;
  name: string;
}

const emptyVariant = (): VariantDraft => ({ sku: "", size: "", color: "", stockQuantity: 0 });

export function ProductForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();

  const [categories, setCategories] = useState<Category[]>([]);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [basePrice, setBasePrice] = useState("");
  const [status, setStatus] = useState<"draft" | "active">("draft");
  const [variants, setVariants] = useState<VariantDraft[]>([emptyVariant()]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get<{ categories: Category[] }>("/categories").then((r) => setCategories(r.categories));
    if (isEdit) {
      api.get<{ product: any }>(`/products/${id}`).then(({ product }) => {
        // Note: GET /products/:slug is by slug in the public API — an admin-specific
        // GET /admin/products/:id (by id, including draft/archived) is a small addition
        // to add server-side alongside the existing admin routes.
        setName(product.name);
        setSlug(product.slug);
        setDescription(product.description);
        setCategoryId(product.categoryId);
        setBasePrice(String(product.basePrice));
        setStatus(product.status);
        setVariants(product.variants.map((v: any) => ({ ...v })));
      });
    }
  }, [id, isEdit]);

  function updateVariant(index: number, patch: Partial<VariantDraft>) {
    setVariants((prev) => prev.map((v, i) => (i === index ? { ...v, ...patch } : v)));
  }

  function removeVariant(index: number) {
    setVariants((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (variants.length === 0) {
      setError("Add at least one size/color variant with a SKU.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name,
        slug,
        description,
        categoryId,
        basePrice: Number(basePrice),
        status,
        variants: variants.map((v) => ({ ...v, stockQuantity: Number(v.stockQuantity) })),
      };

      if (isEdit) {
        await api.patch(`/admin/products/${id}`, payload);
      } else {
        await api.post("/admin/products", payload);
      }
      navigate("/admin/products");
    } catch (err: any) {
      setError(err.message ?? "Could not save product.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-2xl">
      <h1 className="mb-6 font-serif text-2xl">{isEdit ? "Edit product" : "Add product"}</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <Field label="Name">
            <input value={name} onChange={(e) => setName(e.target.value)} required className="input" />
          </Field>
          <Field label="Slug (URL)">
            <input value={slug} onChange={(e) => setSlug(e.target.value)} required className="input" />
          </Field>
        </div>

        <Field label="Description">
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            required
            className="input"
          />
        </Field>

        <div className="grid grid-cols-3 gap-4">
          <Field label="Category">
            <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} required className="input">
              <option value="">Select…</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Base price (PKR)">
            <input
              type="number"
              min="0"
              step="0.01"
              value={basePrice}
              onChange={(e) => setBasePrice(e.target.value)}
              required
              className="input"
            />
          </Field>
          <Field label="Status">
            <select value={status} onChange={(e) => setStatus(e.target.value as "draft" | "active")} className="input">
              <option value="draft">Draft</option>
              <option value="active">Active (visible on storefront)</option>
            </select>
          </Field>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <p className="text-sm font-medium">Variants (size / color / SKU / stock)</p>
            <button
              type="button"
              onClick={() => setVariants((prev) => [...prev, emptyVariant()])}
              className="flex items-center gap-1 text-sm text-[#A98F63]"
            >
              <Plus size={14} /> Add variant
            </button>
          </div>

          <div className="space-y-2">
            {variants.map((v, i) => (
              <div key={i} className="grid grid-cols-[1fr_1fr_1fr_1fr_auto] items-center gap-2">
                <input
                  placeholder="SKU"
                  value={v.sku}
                  onChange={(e) => updateVariant(i, { sku: e.target.value })}
                  required
                  className="input"
                />
                <input
                  placeholder="Size (e.g. M)"
                  value={v.size}
                  onChange={(e) => updateVariant(i, { size: e.target.value })}
                  required
                  className="input"
                />
                <input
                  placeholder="Color"
                  value={v.color}
                  onChange={(e) => updateVariant(i, { color: e.target.value })}
                  required
                  className="input"
                />
                <input
                  type="number"
                  min="0"
                  placeholder="Stock qty"
                  value={v.stockQuantity}
                  onChange={(e) => updateVariant(i, { stockQuantity: Number(e.target.value) })}
                  required
                  className="input"
                />
                <button type="button" onClick={() => removeVariant(i)} className="rounded p-2 hover:bg-[#F0ECE3]">
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {error && (
          <p role="alert" className="text-sm text-[#A5433A]">
            {error}
          </p>
        )}

        <div className="flex gap-3">
          <button type="submit" disabled={saving} className="rounded-md bg-[#1C1C1E] px-5 py-2 text-sm text-[#F7F4EF] disabled:opacity-50">
            {saving ? "Saving…" : isEdit ? "Save changes" : "Create product"}
          </button>
          <button type="button" onClick={() => navigate("/admin/products")} className="rounded-md px-5 py-2 text-sm text-[#8C8A85]">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-[#1C1C1E]">{label}</span>
      {children}
    </label>
  );
}

/* Tailwind note: `.input` is a shared utility class defined once in your global stylesheet:
   .input { @apply w-full rounded-md border border-[#8C8A85] px-3 py-2 text-sm; }            */
