// frontend/src/pages/admin/AdminProducts.tsx
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Search, Pencil, Archive } from "lucide-react";
import { api } from "../../api/client";

interface Variant {
  id: string;
  sku: string;
  size: string;
  color: string;
  stockQuantity: number;
  stockStatus: "in_stock" | "low_stock" | "out_of_stock";
}

interface Product {
  id: string;
  name: string;
  slug: string;
  basePrice: number;
  status: "draft" | "active" | "archived";
  variants: Variant[];
  images: { url: string }[];
}

const statusStyles: Record<Variant["stockStatus"], string> = {
  in_stock: "bg-[#4B7355]/10 text-[#4B7355]",
  low_stock: "bg-[#A98F63]/15 text-[#A98F63]",
  out_of_stock: "bg-[#A5433A]/10 text-[#A5433A]",
};

export function AdminProducts() {
  const [products, setProducts] = useState<Product[] | null>(null);
  const [query, setQuery] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function load() {
    try {
      const { items } = await api.get<{ items: Product[] }>(`/products?limit=100${query ? `&q=${encodeURIComponent(query)}` : ""}`);
      setProducts(items);
    } catch (err: any) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  async function handleArchive(id: string) {
    if (!confirm("Archive this product? It will be hidden from the storefront but past orders keep their record.")) return;
    await api.delete(`/admin/products/${id}`);
    load();
  }

  async function handleStockEdit(variant: Variant, productId: string) {
    const next = prompt(`New stock quantity for SKU ${variant.sku}`, String(variant.stockQuantity));
    if (next === null || Number.isNaN(Number(next))) return;
    await api.patch(`/admin/variants/${variant.id}/stock`, { stockQuantity: Number(next) });
    load();
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-serif text-2xl">Products</h1>
          <p className="text-sm text-[#8C8A85]">Manage catalog, variants, and stock levels.</p>
        </div>
        <Link
          to="/admin/products/new"
          className="flex items-center gap-2 rounded-md bg-[#1C1C1E] px-4 py-2 text-sm text-[#F7F4EF]"
        >
          <Plus size={16} /> Add product
        </Link>
      </div>

      <div className="mb-4 flex items-center gap-2 rounded-md border border-[#E4E0D8] bg-white px-3 py-2">
        <Search size={16} className="text-[#8C8A85]" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products…"
          className="w-full text-sm outline-none"
        />
      </div>

      {error && <p className="text-sm text-[#A5433A]">{error}</p>}

      <div className="overflow-hidden rounded-lg border border-[#E4E0D8] bg-white">
        <table className="w-full text-sm">
          <thead className="border-b border-[#E4E0D8] bg-[#F7F4EF] text-left text-xs uppercase tracking-wide text-[#8C8A85]">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Base price</th>
              <th className="px-4 py-3">Variants / stock</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products === null && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-[#8C8A85]">
                  Loading…
                </td>
              </tr>
            )}
            {products?.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-[#8C8A85]">
                  No products yet — add your first one.
                </td>
              </tr>
            )}
            {products?.map((p) => (
              <tr key={p.id} className="border-b border-[#F0ECE3] last:border-0">
                <td className="flex items-center gap-3 px-4 py-3">
                  {p.images[0] && (
                    <img src={p.images[0].url} alt="" className="h-10 w-10 rounded object-cover" />
                  )}
                  <span>{p.name}</span>
                </td>
                <td className="px-4 py-3 capitalize">{p.status}</td>
                <td className="px-4 py-3">Rs. {Number(p.basePrice).toFixed(2)}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {p.variants.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => handleStockEdit(v, p.id)}
                        title={`Edit stock for ${v.sku}`}
                        className={`rounded px-2 py-0.5 text-xs ${statusStyles[v.stockStatus]}`}
                      >
                        {v.size}/{v.color}: {v.stockQuantity}
                      </button>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Link to={`/admin/products/${p.id}/edit`} className="rounded p-1.5 hover:bg-[#F0ECE3]" title="Edit">
                      <Pencil size={16} />
                    </Link>
                    <button onClick={() => handleArchive(p.id)} className="rounded p-1.5 hover:bg-[#F0ECE3]" title="Archive">
                      <Archive size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
