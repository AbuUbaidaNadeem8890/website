// frontend/src/pages/Checkout.tsx
import { useRef, useState } from "react";
import { api } from "../api/client";
import { useCart } from "../context/CartContext";

interface CheckoutIntentResponse {
  orderId: string;
  actionUrl: string;
  fields: Record<string, string>;
}

export function CheckoutPage({ addressId }: { addressId: string }) {
  const { subtotal, cart } = useCart();
  const [mobile, setMobile] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const [jazzCashFields, setJazzCashFields] = useState<CheckoutIntentResponse | null>(null);

  async function handlePayWithJazzCash(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!/^03\d{9}$/.test(mobile)) {
      setError("Enter a valid mobile number, e.g. 03001234567");
      return;
    }

    setSubmitting(true);
    try {
      // 1. Ask our server to create the pending order + signed JazzCash request
      const intent = await api.post<CheckoutIntentResponse>("/checkout/intent", {
        addressId,
        customerMobile: mobile,
      });
      setJazzCashFields(intent);

      // 2. Auto-submit a hidden form that redirects the browser to JazzCash's hosted page.
      //    (State update above renders the form; submit happens on next tick via useEffect-free ref trick)
      requestAnimationFrame(() => formRef.current?.submit());
    } catch (err: any) {
      setError(err.message ?? "Could not start checkout. Please try again.");
      setSubmitting(false);
    }
  }

  if (!cart || cart.items.length === 0) {
    return <p className="text-[#8C8A85]">Your cart is empty.</p>;
  }

  return (
    <div className="max-w-md space-y-6">
      <form onSubmit={handlePayWithJazzCash} className="space-y-4" aria-label="JazzCash checkout form">
        <div>
          <label htmlFor="mobile" className="block text-sm font-medium text-[#1C1C1E]">
            Mobile number (for JazzCash / Easypaisa)
          </label>
          <input
            id="mobile"
            type="tel"
            inputMode="numeric"
            placeholder="03001234567"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            className="mt-1 w-full rounded-md border border-[#8C8A85] px-3 py-2"
            required
          />
        </div>

        {error && (
          <p role="alert" className="text-sm text-[#A5433A]">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-md bg-[#1C1C1E] py-3 text-[#F7F4EF] disabled:opacity-50"
        >
          {submitting ? "Redirecting to JazzCash…" : `Pay Rs. ${subtotal.toFixed(2)} with JazzCash / Easypaisa`}
        </button>
        <p className="text-xs text-[#8C8A85]">
          Sandbox mode — you'll be redirected to JazzCash's test payment page. No real money moves.
        </p>
      </form>

      {/* Hidden auto-submitting form that performs the actual redirect to JazzCash's hosted page */}
      {jazzCashFields && (
        <form ref={formRef} method="POST" action={jazzCashFields.actionUrl} className="hidden">
          {Object.entries(jazzCashFields.fields).map(([key, value]) => (
            <input key={key} type="hidden" name={key} value={value} />
          ))}
        </form>
      )}
    </div>
  );
}

// Shown on /order-confirmation/:orderId after JazzCash redirects back — polls status
// briefly in case the callback hasn't landed yet (network latency between redirect + webhook).
export function OrderStatusPoller({ orderId, onConfirmed }: { orderId: string; onConfirmed: () => void }) {
  const [status, setStatus] = useState<"checking" | "paid" | "pending" | "failed">("checking");

  async function poll(attempt = 0) {
    try {
      const { status: orderStatus } = await api.get<{ status: string }>(`/checkout/status/${orderId}`);
      if (orderStatus === "paid") {
        setStatus("paid");
        onConfirmed();
        return;
      }
      if (orderStatus === "cancelled") {
        setStatus("failed");
        return;
      }
      if (attempt < 10) {
        setTimeout(() => poll(attempt + 1), 1500);
      } else {
        setStatus("pending");
      }
    } catch {
      setStatus("failed");
    }
  }

  useState(() => {
    poll();
  });

  if (status === "checking") return <p>Confirming your payment with JazzCash…</p>;
  if (status === "paid") return <p className="text-[#4B7355]">Payment confirmed — thank you!</p>;
  if (status === "pending") return <p>Still confirming — we'll email you once it's done.</p>;
  return <p className="text-[#A5433A]">Payment didn't go through. Please try again.</p>;
}
