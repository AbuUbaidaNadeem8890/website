// frontend/src/context/CartContext.tsx
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api } from "../api/client";

interface CartItem {
  id: string;
  quantity: number;
  variant: {
    id: string;
    sku: string;
    size: string;
    color: string;
    priceOverride: number | null;
    product: { name: string; basePrice: number; images: { url: string }[] };
  };
}

interface Cart {
  id: string;
  items: CartItem[];
}

interface CartContextValue {
  cart: Cart | null;
  loading: boolean;
  addItem: (variantId: string, quantity?: number) => Promise<void>;
  updateQuantity: (itemId: string, quantity: number) => Promise<void>;
  removeItem: (itemId: string) => Promise<void>;
  itemCount: number;
  subtotal: number;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<Cart | null>(null);
  const [loading, setLoading] = useState(true);

  async function refreshCart() {
    setLoading(true);
    try {
      const { cart } = await api.get<{ cart: Cart }>("/cart");
      setCart(cart);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refreshCart();
  }, []);

  async function addItem(variantId: string, quantity = 1) {
    const { cart } = await api.post<{ cart: Cart }>("/cart/items", { variantId, quantity });
    setCart(cart);
  }

  async function updateQuantity(itemId: string, quantity: number) {
    const { cart } = await api.patch<{ cart: Cart }>(`/cart/items/${itemId}`, { quantity });
    setCart(cart);
  }

  async function removeItem(itemId: string) {
    const { cart } = await api.delete<{ cart: Cart }>(`/cart/items/${itemId}`);
    setCart(cart);
  }

  const itemCount = cart?.items.reduce((sum, i) => sum + i.quantity, 0) ?? 0;
  const subtotal =
    cart?.items.reduce((sum, i) => {
      const price = i.variant.priceOverride ?? i.variant.product.basePrice;
      return sum + price * i.quantity;
    }, 0) ?? 0;

  return (
    <CartContext.Provider value={{ cart, loading, addItem, updateQuantity, removeItem, itemCount, subtotal }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}

// Call this right after a successful login/register so the guest-session cart
// (stored server-side against a cookie) folds into the user's persistent cart.
export async function mergeGuestCartOnLogin() {
  const { cart } = await api.post<{ cart: Cart }>("/cart/merge", {});
  return cart;
}
